package com.example.android.mystorynews;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class StorynewsActivity extends AppCompatActivity implements android.app.LoaderManager.LoaderCallbacks<ArrayList<Storynews>> {

    /**
     * URL for Storynews data from the USGS dataset
     */
    private static final String REQUEST_URL = " http://content.guardianapis.com/search";

    /**
     * Constant value for the Storynews loader ID.
     */
    private static final int Storynews_LOADER_ID = 1;
    /**
     * Empty Text View
     */
    TextView emptyTextView;
    /**
     * Progress Bar View
     */
    ProgressBar mProgressBar;
    /**
     * Adapter for the list of Storynewss
     */
    private StorynewsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.storynews_activity);

        // Find a reference to the {@link ListView} in the layout
        final ListView StorynewsListView = findViewById(R.id.list);

        //Find the Reference to {@link EmptyTextView} to be Displayed when no data is recieved
        emptyTextView = findViewById(R.id.Empty_txtview);
        StorynewsListView.setEmptyView(emptyTextView);

        //Find the reference to the progress bar
        mProgressBar = findViewById(R.id.progress_bar);


        // Create a new {@link ArrayAdapter} of Storynewss
        adapter = new StorynewsAdapter(this, new ArrayList<Storynews>());

        // Set the adapter on the {@link ListView}
        // so the list can be populated in the user interface
        StorynewsListView.setAdapter(adapter);

        //on listItem click Listener
        StorynewsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // gets the current Storynews
                Storynews currentStorynews = adapter.getItem(position);

                // get the url
                Uri currentStorynewsUri = Uri.parse(currentStorynews.getUrl());

                //start the intent
                Intent launchUrl = new Intent(Intent.ACTION_VIEW, currentStorynewsUri);
                if (launchUrl.resolveActivity(getPackageManager()) != null) {

                    startActivity(launchUrl);

                }

            }
        });

        //Check Whether Internet Connection is Available or Not
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {

            // Get a reference to the LoaderManager, in order to interact with loaders.
            android.app.LoaderManager loaderManager = getLoaderManager();

            // Initialize the loader. Pass in the int ID constant defined above and pass in null for
            // the bundle. Pass in this activity for the LoaderCallbacks parameter (which is valid
            // because this activity implements the LoaderCallbacks interface).
            loaderManager.initLoader(Storynews_LOADER_ID, null, this);

        } else {
            mProgressBar.setVisibility(View.GONE);
            emptyTextView.setText(R.string.no_internet);
        }


    }

    @Override
    public android.content.Loader<ArrayList<Storynews>> onCreateLoader(int id, Bundle args) {


        Uri baseUri = Uri.parse(REQUEST_URL);
        Uri.Builder uriBuilder = baseUri.buildUpon();

        uriBuilder.appendQueryParameter("api-key", "test");  //set the key
        uriBuilder.appendQueryParameter("show-tags", "contributor");  //by revier  show-tags=contributor


        return new StorynewsLoader(this, uriBuilder.toString());

    }

    @Override
    public void onLoadFinished(android.content.Loader<ArrayList<Storynews>> loader, ArrayList<Storynews> Storynewss) {


        //Hide the Loader Once the data Loading is Finished
        mProgressBar.setVisibility(View.GONE);

        // Set empty state text to display "No Storynewss found."
        emptyTextView.setText(R.string.no_Storynewss);

        // Clear the adapter of previous Storynews data
        adapter.clear();


        // If there is a valid list of {@link Storynews}s, then add them to the adapter's
        // data set. This will trigger the ListView to update.
        if (Storynewss != null && !Storynewss.isEmpty()) {
            adapter.addAll(Storynewss);
        }
    }

    @Override
    public void onLoaderReset(android.content.Loader<ArrayList<Storynews>> loader) {
        // Loader reset, so we can clear out our existing data.
        adapter.clear();
    }


}

