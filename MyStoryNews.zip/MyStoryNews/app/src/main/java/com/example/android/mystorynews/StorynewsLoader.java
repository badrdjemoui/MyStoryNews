package com.example.android.mystorynews;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.ArrayList;


public class StorynewsLoader extends AsyncTaskLoader<ArrayList<Storynews>> {


    /**
     * Tag for Log message
     */
    private static final String LOG_TAG = StorynewsLoader.class.getSimpleName();

    /**
     * Query URL
     */
    private String mUrl;

    public StorynewsLoader(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public ArrayList<Storynews> loadInBackground() {
        if (mUrl == null) {
            return null;
        }

        ArrayList<Storynews> Storynews = QueryUtils.fetchStorynewsList(mUrl);

        return Storynews;
    }
}
