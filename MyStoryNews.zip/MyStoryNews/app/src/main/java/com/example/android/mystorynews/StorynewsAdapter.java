package com.example.android.mystorynews;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by admin on 31-07-2016.
 */
public class StorynewsAdapter extends ArrayAdapter<Storynews> {
    private static final String LOG_TAG = QueryUtils.class.getSimpleName();

    public StorynewsAdapter(Context context, ArrayList<Storynews> Storynewss) {
        super(context, 0, Storynewss);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;

        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.storynews_list_item, parent, false);

        }


    Storynews currentStorynews = getItem(position);
    TextView sectioname = listItemView.findViewById(R.id.sectioname);
    sectioname.setText(currentStorynews.getNamesection());
    TextView webtitle = listItemView.findViewById(R.id.webtitle);
    webtitle.setText(currentStorynews.getTitleArticle());
    TextView webpublicationdate = listItemView.findViewById(R.id.webpublicationdate);
    webpublicationdate.setText(currentStorynews.getDatepublished());
    TextView author = listItemView.findViewById(R.id.author);
    author.setText(currentStorynews.getAuthor());


        return listItemView;
    }

}

