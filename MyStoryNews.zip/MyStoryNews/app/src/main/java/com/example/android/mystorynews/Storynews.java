package com.example.android.mystorynews;

public class Storynews {
    // variable to store Storynews information

    private String titleArticle;
    private String namesection;
    private String datepublished;
    private String author;
    private String url;

    public Storynews(String titleArticle, String namesection, String datepublished, String author, String url) {
        this.titleArticle = titleArticle;
        this.namesection = namesection;
        this.datepublished = datepublished;
        this.author = author;
        this.url = url;
    }

    public String getTitleArticle() {
        return titleArticle;
    }

    public void setTitleArticle(String titleArticle) {
        this.titleArticle = titleArticle;
    }

    public String getNamesection() {
        return namesection;
    }

    public void setNamesection(String namesection) {
        this.namesection = namesection;
    }

    public String getDatepublished() {
        return datepublished;
    }

    public void setDatepublished(String datepublished) {
        this.datepublished = datepublished;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
